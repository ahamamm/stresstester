The IBM MQ for Raspberry Pi installable is available for development purposes
only.

----------------------------------------------------------------------------------
IBM MQ for Raspberry Pi is an experimental offering and not all features or
components may be available. IBM reserves the right to withdraw this offering at
anytime without notice. This package is provided "as is" and no support will be
provided by IBM. This offering is not available for purchase.

If you discover a problem with this offering and would like to report it, you
can raise an issue using the following GitHub repository:
https://github.com/ibm-messaging/mq-raspberry-pi-developers

Limited testing has been performed to evaluate a core set of IBM MQ features.
While the package has been compiled for the arm architecture, please note that
testing has been limited to the Raspberry Pi arm6 and arm7 based platforms only.
It is unknown if IBM MQ features work on other arm based platforms.

We are aware of the following limitations:

1. The IBM MQ XR component which provides MQTT based messaging is not available.

2. AMQP based messaging is not available.

3. It is not possible to configure the queue manager with TLS using the arm6
architecture (Raspberry Pi Zero platform). IBM MQ using a TLS configuration has
been demonstrated using the Raspberry Pi 3 and Raspberry Pi 4 platforms (arm7
architecture).

4. Testing with the IBM MQ Console was limited to using local OS registry
configuration.

If you or any of your company's affiliates provides IBM Corporation or any of
its affiliates (either directly or via an IBM business partner) with any
feedback (including suggestions, data and/or written materials) in relation to
(i) IBM MQ for Raspberry Pi, or (ii) IBM Corporation or its affiliates products
or services, then IBM Corporation and its affiliates shall be free to use such
feedback for any purpose, including (without limitation) the development,
manufacture and marketing of products and services. For clarification purposes,
the foregoing provisions shall not provide the right for IBM Corporation or any
of its affiliates to identify you as the source of any such feedback.

Raspberry Pi is a trademark of the Raspberry Pi Foundation.
----------------------------------------------------------------------------------

